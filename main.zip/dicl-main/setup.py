from setuptools import setup

# For retrocompatibility with pip < 22 in editable mode
setup()
